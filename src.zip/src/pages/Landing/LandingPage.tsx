import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { Globe, BarChart3, Zap, ChevronRight, Database, Scan } from 'lucide-react';
import Logo from '../../components/UI/Logo';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white dark:bg-[#020617] pt-16 transition-colors duration-300 landing-container">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-32">
        <div className="container mx-auto px-6 relative z-10">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="flex-1 text-center lg:text-left">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <span className="inline-block bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-widest mb-6">
                  Next-Gen Retail Ecosystem
                </span>
                <h1 className="text-5xl lg:text-7xl font-black text-slate-900 dark:text-white leading-[1.1] mb-8 tracking-tight">
                  Transformasi Kantin Kejujuran Menjadi <span className="text-blue-600 dark:text-blue-400">Ekosistem Digital</span> Berbasis AI
                </h1>
                <p className="text-lg text-slate-500 dark:text-slate-400 max-w-2xl mx-auto lg:mx-0 mb-10 leading-relaxed">
                  Monitoring jarak jauh <span className="font-bold text-slate-800 dark:text-slate-200">±15 km</span> dengan akurasi deteksi produk <span className="font-bold text-slate-800 dark:text-slate-200">90%</span> menggunakan <span className="text-blue-600 dark:text-blue-400 font-bold">Hybrid Edge Computing</span>.
                </p>
                <div className="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start">
                  <Link to="/kasir" className="w-full sm:w-auto bg-blue-600 text-white px-8 py-4 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-xl shadow-blue-500/30 hover:bg-blue-700 transition-all active:scale-95">
                    Mulai Kasir
                    <ChevronRight className="w-5 h-5" />
                  </Link>
                </div>
              </motion.div>
            </div>
            
            <div className="flex-1 relative">
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="relative z-10"
              >
                {/* Isometric Smart Store Illustration Placeholder */}
                <div className="relative w-full aspect-square bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-[4rem] border border-blue-100 dark:border-white/10 shadow-2xl overflow-hidden flex items-center justify-center p-12">
                  <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(#1e40af 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
                  
                  <div className="relative w-full h-full">
                    {/* Floating Elements to simulate 3D/Isometric */}
                    <motion.div 
                      animate={{ y: [0, -20, 0] }}
                      transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                      className="absolute top-0 left-0 w-32 h-32 bg-white dark:bg-slate-800 rounded-3xl shadow-xl border border-blue-100 dark:border-white/10 flex items-center justify-center"
                    >
                      <Scan className="w-12 h-12 text-blue-600 dark:text-blue-400" />
                    </motion.div>
                    
                    <motion.div 
                      animate={{ y: [0, 20, 0] }}
                      transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                      className="absolute bottom-10 right-0 w-40 h-40 bg-white dark:bg-slate-800 rounded-3xl shadow-xl border border-blue-100 dark:border-white/10 p-6 flex flex-col justify-between"
                    >
                      <div className="flex justify-between items-center">
                        <Zap className="w-6 h-6 text-amber-500" />
                        <span className="text-[10px] font-bold text-emerald-500">LIVE</span>
                      </div>
                      <div className="space-y-2">
                        <div className="h-2 w-full bg-slate-100 dark:bg-white/10 rounded-full overflow-hidden">
                          <motion.div animate={{ width: ['20%', '80%', '40%'] }} transition={{ duration: 3, repeat: Infinity }} className="h-full bg-blue-500" />
                        </div>
                        <div className="h-2 w-2/3 bg-slate-100 dark:bg-white/10 rounded-full" />
                      </div>
                    </motion.div>

                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-blue-600 rounded-[2.5rem] shadow-2xl shadow-blue-500/40 flex items-center justify-center rotate-12">
                       <Database className="w-20 h-20 text-white -rotate-12" />
                    </div>
                  </div>
                </div>
              </motion.div>
              
              {/* Background Glow */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-blue-400/10 blur-[120px] rounded-full -z-10" />
            </div>
          </div>
        </div>
      </section>

      {/* Feature Grid */}
      <section className="py-24 bg-slate-50 dark:bg-white/5">
        <div className="container mx-auto px-6">
          <div className="text-center max-w-3xl mx-auto mb-20">
            <h2 className="text-4xl font-black text-slate-900 dark:text-white mb-6 uppercase tracking-tight">Teknologi Masa Depan Retail</h2>
            <p className="text-slate-500 dark:text-slate-400">Kami menggabungkan kecerdasan buatan dengan infrastruktur edge computing untuk menciptakan pengalaman belanja yang mulus dan aman.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "AI Vision Scanner",
                desc: "Identifikasi produk non-barcode secara otomatis dengan tingkat akurasi tinggi menggunakan model computer vision terkini.",
                icon: Scan,
                color: "bg-cobalt-600"
              },
              {
                title: "Real-time Inventory",
                desc: "Notifikasi stok kritis otomatis ke pusat. Pantau pergerakan barang secara langsung dari dashboard admin.",
                icon: BarChart3,
                color: "bg-indigo-600"
              },
              {
                title: "Hybrid Edge-Cloud",
                desc: "Sistem tetap jalan meski internet tidak stabil. Pemrosesan data dilakukan di lokal (Edge) dan disinkronkan ke Cloud.",
                icon: Globe,
                color: "bg-emerald-600"
              }
            ].map((feature, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white dark:bg-slate-800 p-10 rounded-[2.5rem] border border-slate-200 dark:border-white/10 hover:border-cobalt-600 transition-all hover:shadow-2xl hover:shadow-blue-500/5 group"
              >
                <div className={`w-14 h-14 ${feature.color} rounded-2xl flex items-center justify-center mb-8 shadow-lg group-hover:scale-110 transition-transform`}>
                  <feature.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-black text-slate-900 dark:text-white mb-4 uppercase tracking-tight">{feature.title}</h3>
                <p className="text-slate-500 dark:text-slate-400 leading-relaxed text-sm">
                  {feature.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24">
        <div className="container mx-auto px-6">
          <div className="bg-cobalt-600 rounded-[3rem] p-12 lg:p-20 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/20 blur-[100px] rounded-full" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-indigo-500/20 blur-[100px] rounded-full" />
            
            <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
              <div>
                <p className="text-5xl font-black text-white mb-2">90%</p>
                <p className="text-blue-200 text-sm font-bold uppercase tracking-widest">Akurasi Deteksi</p>
              </div>
              <div>
                <p className="text-5xl font-black text-white mb-2">15km</p>
                <p className="text-blue-200 text-sm font-bold uppercase tracking-widest">Jangkauan Monitoring</p>
              </div>
              <div>
                <p className="text-5xl font-black text-white mb-2">&lt;100ms</p>
                <p className="text-blue-200 text-sm font-bold uppercase tracking-widest">Latensi Sinkronisasi</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-slate-100 dark:border-white/10">
        <div className="container mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <Link to="/" className="flex items-center gap-4">
            <Logo />
          </Link>
          <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">
            © 2026 Koperasi GIAT Modern AI POS. All rights reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-slate-400 hover:text-cobalt-600 transition-colors"><Globe className="w-5 h-5" /></a>
            <a href="#" className="text-slate-400 hover:text-cobalt-600 transition-colors"><Zap className="w-5 h-5" /></a>
          </div>
        </div>
      </footer>
    </div>
  );
}
